package com.example.sagar.demo.services;

import java.util.List;
import org.springframework.stereotype.Component;
import com.example.sagar.demo.entities.Product;

@Component
public interface ProductService{

	public List<Product> findByName(String name);
	public List<Product> findByPriceGreaterThan(int price); 
	public List<Product> findByBrandAndPrice(String brand, int price);
	public List<Product> findAll();
	public Product findById(int id);
	public Product saveProduct(Product product);
	public Product updateProduct(Product product);
	public void deleteProduct(int id);
}
