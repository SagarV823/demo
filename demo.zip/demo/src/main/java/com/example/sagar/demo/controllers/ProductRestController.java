package com.example.sagar.demo.controllers;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.example.sagar.demo.entities.Product;
import com.example.sagar.demo.repositories.ProductRepository;
import com.example.sagar.demo.services.ProductService;

@RestController
public class ProductRestController {

	@Autowired
	private ProductService productService;
	
//	@Autowired
//	private ProductRepository repository;
	
	//all products
	@RequestMapping(value="/products",method=RequestMethod.GET)
	public List<Product> getProducts(){
		return productService.findAll();
	}
	
	//fetch by Id
	@RequestMapping(value="/products/{id}",method=RequestMethod.GET)
	public Product getProduct(@PathVariable("id") int id){
		return productService.findById(id);
	}
	
	//By brand name
	@RequestMapping(value="/productsbrand/{brand}",method=RequestMethod.GET)
	public List<Product> getProductByBrand(@PathVariable("brand") String brand){
		return productService.findByName(brand);
	}
	
	//by price
	@RequestMapping(value="/productsprice/{price}",method=RequestMethod.GET)
	public List<Product> getProductByPrice(@PathVariable("price") int price){
		return productService.findByPriceGreaterThan(price);
	}
	
	//Specific brand and price
	@RequestMapping(value="/productsprice",method=RequestMethod.GET)
	public List<Product> getProductByBrandPrice(@RequestParam("brand") String brand,@RequestParam("price") int price){
		return productService.findByBrandAndPrice(brand,price);
	}
	
	//Add a new product
	@RequestMapping(value="/products",method=RequestMethod.POST)
	public Product createProduct(@RequestBody Product product){
		return productService.saveProduct(product);
	}
	
	//Update an existing product
	@RequestMapping(value="/products",method=RequestMethod.PUT)
	public Product updateProduct(@RequestBody Product product){
		return productService.updateProduct(product);
	}
	
	//Delete and existing
	@RequestMapping(value="/products/{id}",method=RequestMethod.DELETE)
	public void deleteProduct(@PathVariable("id") int id){
		productService.deleteProduct(id);
	}
	
}
