package com.example.sagar.demo.services;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.example.sagar.demo.entities.Product;
import com.example.sagar.demo.repositories.ProductRepository;

@Service("productServiceImpl")
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductRepository pRepository;
	
	@Transactional
	public List<Product> findByName(String brandname) {
		return pRepository.findByBrand(brandname); 
	}

	@Transactional
	public List<Product> findByPriceGreaterThan(int price) {
		return pRepository.findByPriceGreaterThan(price);
	}

	@Transactional
	public List<Product> findByBrandAndPrice(String brandname, int price) {
		List<Product> productlist=new ArrayList<Product>();
		List<Product> resultlist=pRepository.findByPriceLessThan(price);
		for(Product product:resultlist) {
			if(product.getBrand().equals(brandname)) 
				productlist.add(product);
		}
		return productlist;
	}

	public List<Product> findAll() {
		return pRepository.findAll();
	}

	public Product findById(int id) {
		return pRepository.findById(id).get();
	}

	public Product saveProduct(Product product) {
		return pRepository.save(product);
	}

	public Product updateProduct(Product product) {
		return pRepository.save(product);
	}

	public void deleteProduct(int id) {
		pRepository.deleteById(id);
	}



}
