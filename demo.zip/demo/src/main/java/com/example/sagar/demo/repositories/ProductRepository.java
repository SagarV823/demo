package com.example.sagar.demo.repositories;

import java.io.Serializable;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.sagar.demo.entities.Product;

@Repository
public interface ProductRepository extends JpaRepository<Product,Integer>{
	
//	@Query("select s from Product p where s.name = ?1")
	public List<Product> findByBrand(String name);
	public List<Product> findByPriceGreaterThan(int price);
	public List<Product> findByPriceLessThan(int price);
}
